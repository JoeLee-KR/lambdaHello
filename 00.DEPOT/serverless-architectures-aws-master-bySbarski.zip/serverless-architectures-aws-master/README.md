# serverless-architectures-aws
The code repository for the Serverless Architectures on AWS book
