var configConstants = {
	auth0: {
		domain: 'cloudmonitor.auth0.com',
		clientId: 'r8PQy2Qdr91xU3KTGQ01e598bwee8MQr',
		target: 'r8PQy2Qdr91xU3KTGQ01e598bwee8MQr',
		grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
		api_type: 'firebase',
		scope: 'openid'
	},
	firebase: {
		apiKey: 'AIzaSyDtZhtFVDlg-7fzBHxhcIWO6uLPpGE8K_E',
		databaseURL: 'https://hour-video-9c400.firebaseio.com'
	},
  apiBaseUrl: 'https://tlzyo7a7o9.execute-api.us-east-1.amazonaws.com/dev'
};
