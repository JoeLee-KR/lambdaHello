var configConstants = {
	auth0: {
		domain: 'cloudmonitor.auth0.com',
		clientId: 'r8PQy2Qdr91xU3KTGabc598bwee8MQr'
	},
	firebase: {
		apiKey: 'AIzaSyDtZhtFV21g-7fzBHxhcIWO61LPpGE8K_E',
		databaseURL: 'https://hour-video-9c401.firebaseio.com'
	},
  apiBaseUrl: 'https://bl5yo7512.execute-api.us-east-1.amazonaws.com/dev'
};
