var configConstants = {
	auth0: {
		domain: 'AUTH0-DOMAIN',
		clientId: 'AUTH0-CLIENTID'
	},
  apiBaseUrl: 'https://API-GATEWAY-URL/dev'
};
