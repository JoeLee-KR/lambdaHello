/**
 * Created by Peter Sbarski
 * Serverless Architectures on AWS
 * http://book.acloud.guru/
 * Last Updated: Feb 11, 2017
 */


(function(){
	$(document).ready(function(){
		userController.init(configConstants);
	});
}());
