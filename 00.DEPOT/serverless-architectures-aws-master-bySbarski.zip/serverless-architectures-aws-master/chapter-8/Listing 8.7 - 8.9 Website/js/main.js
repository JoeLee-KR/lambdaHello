(function(){
	$(document).ready(function(){
		userController.init(configConstants);
		videoController.init(configConstants);
		uploadController.init(configConstants);
	});
}());
