var configConstants = {
	auth0: {
		domain: 'cloudmonitor.auth0.com',
		clientId: 'r8PQy2Qdr91xU3KTGQ01e598bwee8MQr'
	},
  apiBaseUrl: 'https://tlzyo7a7o9.execute-api.us-east-1.amazonaws.com/dev'
};
