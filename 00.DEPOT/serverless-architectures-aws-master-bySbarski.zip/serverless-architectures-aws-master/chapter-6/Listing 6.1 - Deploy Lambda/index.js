/**
 * Created by Peter Sbarski
 * Serverless Architectures on AWS
 * http://book.acloud.guru/
 * Last Updated: Feb 11, 2017
 */

'use strict'; 

exports.handler = function(event, context, callback) {
    callback(null, 'Serverless Architectures on AWS');          
};
